from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_caching import Cache
from flask_dance.contrib.google import make_google_blueprint, google
import chatbot_logic

app = Flask(__name__)
app.secret_key = 'your_secret_key'
cache = Cache(app, config={'CACHE_TYPE': 'simple'})

# Google OAuth setup
google_bp = make_google_blueprint(client_id='YOUR_GOOGLE_CLIENT_ID', client_secret='YOUR_GOOGLE_CLIENT_SECRET', redirect_to='google_login')
app.register_blueprint(google_bp, url_prefix='/google_login')

@app.route('/')
def index():
    if 'user' in session:
        return redirect(url_for('home'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if chatbot_logic.verify_user(username, password):
            session['user'] = username
            return redirect(url_for('home'))
        flash('Invalid credentials. Please try again.')
    return render_template('login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        email_phone = request.form['email_phone']
        password = request.form['password']
        if chatbot_logic.create_user(email_phone, password):
            session['user'] = email_phone
            return redirect(url_for('home'))
        flash('User already exists. Please try a different email/phone number.')
    return render_template('signup.html')

@app.route('/google_login')
def google_login():
    if not google.authorized:
        return redirect(url_for('google.login'))
    resp = google.get('/plus/v1/people/me')
    assert resp.ok, resp.text
    email = resp.json()['emails'][0]['value']
    session['user'] = email
    return redirect(url_for('home'))

@app.route('/home', methods=['GET', 'POST'])
@cache.cached(timeout=60)
def home():
    if 'user' not in session:
        return redirect(url_for('login'))

    recommendations = [
        ('Phones', 'https://www.amazon.in/s?k=phones'),
        ('Shoes', 'https://www.amazon.in/s?k=shoes')
    ]

    queries = [
        ('show me phones', 'https://www.amazon.in/s?k=phones'),
        ('I want to buy shoes', 'https://www.amazon.in/s?k=shoes'),
        ('do you have laptops?', 'https://www.amazon.in/s?k=laptops'),
        ('recommend me a book', 'https://www.amazon.in/s?k=books'),
        ('add phone to cart', 'https://www.amazon.in/s?k=phones&ref=cart'),
        ('checkout my cart', 'https://www.amazon.in/cart'),
        ('track my order', 'https://www.amazon.in/gp/css/order-history'),
        ('do you sell cameras?', 'https://www.amazon.in/s?k=cameras'),
        ('find me a tablet', 'https://www.amazon.in/s?k=tablets'),
        ('search for headphones', 'https://www.amazon.in/s?k=headphones'),
        ('buy a smart watch', 'https://www.amazon.in/s?k=smartwatches'),
        ('show me the latest TV', 'https://www.amazon.in/s?k=TVs'),
        ('recommend a gaming laptop', 'https://www.amazon.in/s?k=gaming+laptops'),
        ('what about kitchen appliances?', 'https://www.amazon.in/s?k=kitchen+appliances'),
        ('get me a sofa', 'https://www.amazon.in/s?k=sofas'),
        ('I need a camera', 'https://www.amazon.in/s?k=cameras'),
        ('show me wireless routers', 'https://www.amazon.in/s?k=wireless+routers'),
        ('buy a printer', 'https://www.amazon.in/s?k=printers'),
        ('show me phone cases', 'https://www.amazon.in/s?k=phone+cases')
    ]

    return render_template('home.html', recommendations=recommendations, queries=queries)

@app.route('/product', methods=['POST'])
def product():
    query = request.form.get('query')
    search_query = chatbot_logic.get_amazon_link(query)
    return redirect(search_query)

@app.route('/logout')
def logout():
    session.pop('user', None)
    return redirect(url_for('login'))

@app.route('/result')
def result():
    return render_template('result.html')

if __name__ == '__main__':
    app.run(debug=True)



