import sqlite3

def verify_user(username, password):
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM users WHERE username=? AND password=?', (username, password))
    user = cursor.fetchone()
    conn.close()
    return user is not None

def create_user(username, password):
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    try:
        cursor.execute('INSERT INTO users (username, password) VALUES (?, ?)', (username, password))
        conn.commit()
        conn.close()
        return True
    except sqlite3.IntegrityError:
        conn.close()
        return False

def get_amazon_link(query):
    links = {
        'phones': 'https://www.amazon.in/s?k=phones&crid=3SX05H5T0Z3Q5&sprefix=%2Caps%2C304&ref=nb_sb_ss_recent_2_0_recent',
        'shoes': 'https://www.amazon.in/s?k=shoes&crid=PFZXBL501X61&sprefix=shoes%2Caps%2C248&ref=nb_sb_noss_2',
        'laptops': 'https://www.amazon.in/s?k=laptops&crid=J8OLMZMW2NH2&sprefix=laptops%2Caps%2C279&ref=nb_sb_noss_2',
        'book': 'https://www.amazon.com/s?k=book',
        'camera': 'https://www.amazon.com/s?k=camera',
        'tablet': 'https://www.amazon.com/s?k=tablet',
        'headphones': 'https://www.amazon.com/s?k=headphones',
        'smart watch': 'https://www.amazon.com/s?k=smart+watch',
        'TV': 'https://www.amazon.com/s?k=TV',
        'gaming laptop': 'https://www.amazon.com/s?k=gaming+laptop',
        'kitchen appliances': 'https://www.amazon.com/s?k=kitchen+appliances',
        'sofa': 'https://www.amazon.com/s?k=sofa',
        'wireless routers': 'https://www.amazon.com/s?k=wireless+routers',
        'printer': 'https://www.amazon.com/s?k=printer',
        'phone cases': 'https://www.amazon.com/s?k=phone+cases'
    }
    return links.get(query.lower(), 'https://www.amazon.com')

